package com.example.test2;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class HelloApplication extends Application {

    private static String URL = "jdbc:mysql://localhost:3306/products";
    private static String USER = "root";
    private static String PASS = null;
    private static String QUERY = "select * from product";


    @Override
    public void start(Stage stage) throws IOException {
        Label nLabel = new Label("Name: ");
        Label pLabel = new Label("Price: ");
        TextField nTextField = new TextField();
        TextField pTextField = new TextField();
        Button dataButton = new Button("Add to database");
        Button pieButton = new Button("PieChart");

        GridPane gridPane = new GridPane();
        gridPane.addColumn(0, nLabel, nTextField);
        gridPane.addColumn(0, pLabel, pTextField);
        gridPane.addColumn(0, dataButton);
        gridPane.addColumn(0, pieButton);

        dataButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    Connection connection = DriverManager.getConnection(URL, USER, PASS);
                    Statement statement = connection.createStatement();

                    String name = nTextField.getText();
                    double price = Double.parseDouble(pTextField.getText());

                    Product product = new Product(name, price);
                    LocalDateTime localDateTime = LocalDateTime.now();
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
                    String formatDate = localDateTime.format(dateTimeFormatter);

                    PreparedStatement preparedStatement = connection.prepareStatement("insert into product (name, price, datatime) values (?, ?, ?)");
                    preparedStatement.setString(1, product.getName());
                    preparedStatement.setDouble(2, product.getPrice());
                    preparedStatement.setString(3, formatDate);
                    preparedStatement.execute();

                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        pieButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Connection connection = null;
                try {
                    connection = DriverManager.getConnection(URL, USER, PASS);
                    Statement statement = connection.createStatement();
                    ResultSet resultSet = statement.executeQuery(QUERY);


                    ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
                    while(resultSet.next()){
                        String resultName = resultSet.getString("name");
                        String resultData = resultSet.getString("datatime");
                        String combo = resultName+" "+resultData;
                        PieChart.Data data = new PieChart.Data(
                                combo,
                                resultSet.getDouble("price")
                        );
                        pieData.add(data);
                    }

                    PieChart pieChart = new PieChart(pieData);
                    gridPane.addColumn(0, pieChart);

                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });



        Scene scene = new Scene(gridPane, 600, 600);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}

